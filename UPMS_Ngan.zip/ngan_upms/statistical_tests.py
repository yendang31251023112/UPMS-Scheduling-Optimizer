"""Kiểm định Mann–Whitney U, Wilcoxon signed-rank và hiệu chỉnh Holm."""
from __future__ import annotations
from collections import defaultdict
from pathlib import Path
import csv

try:
    from scipy.stats import mannwhitneyu, wilcoxon
except ImportError as exc:
    raise ImportError("Cần scipy để kiểm định thống kê: pip install scipy") from exc


def holm_adjust(p_values):
    """Holm-Bonferroni step-down; trả p-value đã hiệu chỉnh theo đúng thứ tự đầu vào."""
    p_values = [float(p) for p in p_values]
    if any(not 0.0 <= p <= 1.0 for p in p_values):
        raise ValueError("Mọi p-value phải nằm trong [0, 1].")
    m = len(p_values)
    order = sorted(range(m), key=lambda i: p_values[i])
    adjusted = [0.0] * m
    running_max = 0.0
    for rank, idx in enumerate(order):
        candidate = min(1.0, (m - rank) * p_values[idx])
        running_max = max(running_max, candidate)
        adjusted[idx] = running_max
    return adjusted


def compare_algorithms(rows, algorithm_a="GA", algorithm_b="WOA", alpha=0.05):
    """So sánh từng dataset. MWU là kiểm định độc lập; Wilcoxon ghép cặp theo seed."""
    grouped = defaultdict(dict)
    for row in rows:
        dataset = str(row["dataset"])
        algorithm = str(row["algorithm"])
        grouped[dataset].setdefault(algorithm, {})[int(row["seed"])] = float(row["makespan"])

    records = []
    for dataset, algs in sorted(grouped.items()):
        if algorithm_a not in algs or algorithm_b not in algs:
            continue
        a_by_seed, b_by_seed = algs[algorithm_a], algs[algorithm_b]
        a = list(a_by_seed.values())
        b = list(b_by_seed.values())
        if not a or not b:
            continue
        mwu_p = float(mannwhitneyu(a, b, alternative="two-sided", method="auto").pvalue)
        common = sorted(set(a_by_seed) & set(b_by_seed))
        if len(common) < 2:
            wilcoxon_p = float("nan")
            paired_n = len(common)
        else:
            paired_a = [a_by_seed[s] for s in common]
            paired_b = [b_by_seed[s] for s in common]
            try:
                wilcoxon_p = float(wilcoxon(paired_a, paired_b, alternative="two-sided").pvalue)
            except ValueError:  # Tất cả sai khác bằng 0
                wilcoxon_p = 1.0
            paired_n = len(common)
        records.append({
            "dataset": dataset, "algorithm_a": algorithm_a, "algorithm_b": algorithm_b,
            "n_a": len(a), "n_b": len(b), "paired_n": paired_n,
            "mann_whitney_u_p": mwu_p, "wilcoxon_p": wilcoxon_p,
        })

    # Hiệu chỉnh Holm chung trên toàn bộ p-value hợp lệ của cả hai phép kiểm định.
    refs, values = [], []
    for i, record in enumerate(records):
        for key in ("mann_whitney_u_p", "wilcoxon_p"):
            p = record[key]
            if p == p:  # bỏ NaN
                refs.append((i, key))
                values.append(p)
    adjusted = holm_adjust(values)
    for (i, key), p_adj in zip(refs, adjusted):
        records[i][key.replace("_p", "_p_holm")] = p_adj
    for record in records:
        for key in ("mann_whitney_u_p_holm", "wilcoxon_p_holm"):
            p = record.get(key)
            record[key.replace("_p_holm", "_significant")] = (
                bool(p < alpha) if p is not None else None
            )
    return records


def save_statistical_tests(records, path):
    if not records:
        raise ValueError("Không có kết quả kiểm định để lưu.")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        writer.writeheader()
        writer.writerows(records)
    return path
