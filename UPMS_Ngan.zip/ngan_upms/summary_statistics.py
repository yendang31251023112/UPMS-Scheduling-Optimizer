"""Tổng hợp thống kê mô tả cho kết quả benchmark."""
from __future__ import annotations
import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev


REQUIRED_COLUMNS = {"algorithm", "dataset", "seed", "makespan", "runtime", "evaluation_count"}


def _validate_rows(rows):
    if not rows:
        raise ValueError("Không có dữ liệu benchmark để thống kê.")
    missing = REQUIRED_COLUMNS - set(rows[0])
    if missing:
        raise ValueError(f"Thiếu cột bắt buộc: {sorted(missing)}")
    for i, row in enumerate(rows):
        for key in ("makespan", "runtime"):
            value = float(row[key])
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"Dòng {i}: {key} phải hữu hạn và không âm.")


def load_raw_results(path):
    with Path(path).open("r", newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    _validate_rows(rows)
    for row in rows:
        row["seed"] = int(row["seed"])
        row["makespan"] = float(row["makespan"])
        row["runtime"] = float(row["runtime"])
        row["evaluation_count"] = int(row["evaluation_count"])
    return rows


def summarize_results(rows):
    """Trả về list dict theo dataset/algorithm: Best, Worst, Mean, Sample StdDev, Runtime."""
    _validate_rows(rows)
    groups = defaultdict(list)
    for row in rows:
        groups[(str(row["dataset"]), str(row["algorithm"]))].append(row)
    output = []
    for (dataset, algorithm), group in sorted(groups.items()):
        values = [float(r["makespan"]) for r in group]
        runtimes = [float(r["runtime"]) for r in group]
        output.append({
            "dataset": dataset,
            "algorithm": algorithm,
            "runs": len(group),
            "Best": min(values),
            "Worst": max(values),
            "Mean": mean(values),
            "Sample StdDev": stdev(values) if len(values) > 1 else 0.0,
            "Runtime Mean": mean(runtimes),
            "Runtime Sample StdDev": stdev(runtimes) if len(runtimes) > 1 else 0.0,
            "Mean NFE": mean(int(r["evaluation_count"]) for r in group),
        })
    return output


def save_summary_csv(summary, path):
    if not summary:
        raise ValueError("Summary rỗng.")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)
    return path
